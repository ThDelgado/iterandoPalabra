evaluacion 
 OPERADORES LÓGICOS 
 ITERANDO UNA PALABRA 
 m3s5


 Thelma Delgado

 para clonar:
 https://github.com/ThDelgado/iterandoPalabra.git